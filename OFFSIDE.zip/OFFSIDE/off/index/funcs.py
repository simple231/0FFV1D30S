from requests import request
from bs4 import BeautifulSoup

"""
    Cria elabora o link apartir  da Barra de pesquisa e exporta cada filme (Links, Imagens e Texto)
    da pagina de pesquisa do site.
"""
def UrlSearchFilmes(pesquisa,genero,ordem):
    req = request('GET', 'http://tugaflix.xyz/filmes?pesquisa=' + pesquisa + '&genero=' + genero + '&ordem=' + ordem)
    code = req.text
    html_parse = BeautifulSoup(code, 'html.parser')
    filexp = open("filme.html", "w")
    for figure in html_parse.find_all('figure'):
        filexp.write(str(figure) + str("\n\r"))
    else:
        filexp.write(str(p))
"""
    Cria elabora o link apartir  da Barra de pesquisa e exporta cada filme (Links, Imagens e Texto)
    da pagina de pesquisa do site.
"""

def UrlSearchSeries(pesquisa,genero,ordem):
    req = request('GET', 'http://tugaflix.xyz/series?pesquisa=' + pesquisa + '&genero=' + genero + '&ordem=' + ordem)
    code = req.text
    html_parse = BeautifulSoup(code, 'html.parser')
    filexp = open("series.html", "w")
    for figure in html_parse.find_all('figure'):
        filexp.write(str(figure) + str("\n\r"))
    else:
        for p in html_parse.find_all('p'):
            filexp.write(str(p))