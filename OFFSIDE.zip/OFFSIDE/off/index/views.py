from django.shortcuts import render

def IndexOfficial(request):
    req = render(request, "Main/search.html")
    return req